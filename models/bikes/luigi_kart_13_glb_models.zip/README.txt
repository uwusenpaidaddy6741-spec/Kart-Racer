Luigi Kart GLB Vehicle Set

Generated replacement GLB models:
Bikes:
- apex_rider.glb
- bobs_bike.glb
- rocket_bike.glb

Karts:
- rocket.glb
- speedster.glb
- balanced.glb
- drifter.glb
- heavy.glb
- blaze.glb
- accelerator.glb
- comet.glb
- turbo.glb
- overdrive.glb

Champion Bike is intentionally not included because the existing champion_bike.glb
already belongs in models/bikes/.

All models are standalone GLB scenes with PBR materials and game-ready geometry.
